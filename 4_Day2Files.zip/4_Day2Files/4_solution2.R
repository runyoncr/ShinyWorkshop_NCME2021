
library(shiny)
library(datasets)
library(shinyWidgets)
library(shinydashboard)
library(shinyjs)



ui <- dashboardPage(
  
  skin = "purple",
  dashboardHeader(title = "Data Explorer"),
  
  dashboardSidebar(
    sliderInput("mean1", label = h4("Group 1 Mean"), min = 200, 
                max = 500, value = 350, step = 10),
    sliderInput("sd1", label = h4("Group 1 SD"), min = 5,
                          max = 40, value = 10, step = 1),
    hr(),
    sliderInput("mean2", label = h4("Group 2 Mean"), min = 20,
                max = 100, value = 50, step = 5),
    sliderInput("sd2", label = h4("Group 2 SD"), min = 1,
                max = 10, value =2, step = 0.50)
  ),
  
  dashboardBody(
    box(title = "Table Output", width = 6, status = "info", 
        solidHeader = TRUE, collapsible = TRUE,
        dataTableOutput(outputId = "exampleTable")),
    
    box(title = "Plot Output", width = 6, status = "success", 
        solidHeader = TRUE, collapsible = TRUE,
        plotlyOutput(outputId = "examplePlotly")),
    
    hr(),
    fluidRow(
      column(4, numericInput("sampN", label = h4("Sample Size"), value = 500,
                             min = 100, max = 1000, step = 50)),
      column(4, numericInput("sampR", label = h4("Sample Correlation"), value = 0,
                             min = -.99, max = .99, step = 0.01)),
      column(4, actionButton(inputId = "genData", 
                             label = "Generate Data")))))

server <- function(input, output) {
  
  rdf <- eventReactive(input$genData,{
    as.data.frame(round(rmvnorm(input$sampN,
                                mean = c(input$mean1, input$mean2),
                                sigma = diag(sqrt(c(input$sd1, input$sd2))) %*% 
                                  matrix(c(1, input$sampR, input$sampR, 1), nrow = 2) %*%
                                  t(diag(sqrt(c(input$sd1, input$sd2))))))) %>% 
      mutate(ID = 1:input$sampN) %>%
      relocate(ID) %>%
      rename("Variable1" = V1, "Variable2" = V2)
  })
  
  output$exampleTable <- renderDataTable(rdf(), options = list(rownames = FALSE))
  
  output$examplePlotly <- renderPlotly({
    p <- ggplot(data = rdf(), aes(x = Variable1, y = Variable2)) + 
      geom_count() + geom_smooth()
    ggplotly(p)
  })
  
}

# Run the application 
shinyApp(ui = ui, server = server)