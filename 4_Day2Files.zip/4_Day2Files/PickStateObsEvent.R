
library(shiny)
library(datasets)
library(shinyWidgets)
library(shinyjs)

ui <- fluidPage(
  
  fluidRow(
    useShinyjs(),
    column(4, 
           ### Input
           div(id = "inputselect",
           selectInput("select", label = h3("Select a State"), 
                       choices = list(state.abb = state.abb), 
                       selected = 1)),
           actionButton("getTheFlag", "Show me the Flag"),
    
          ### Output
           imageOutput("state_flag")
)))



server <- function(input, output) {
  
  shinyjs::onclick("getTheFlag", shinyjs::disable("inputselect"))

  observeEvent(input$getTheFlag,
               {output$state_flag <- renderImage({
                 return(list(
                   src = paste0("www/", tolower(input$select), ".png"),
                   contentType = "www/png",
                   alt = "Face"
                 ))
                 }, deleteFile = FALSE)
               })
  
}


# Run the application 
shinyApp(ui = ui, server = server)