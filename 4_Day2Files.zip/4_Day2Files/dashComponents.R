library(shiny)
library(shinydashboard)

ui <- dashboardPage(
  dashboardHeader(title = "dashboardHeader"),
  
  dashboardSidebar(
    sidebarMenu(
      menuItem("menuItem", tabName = "demo"),
      menuItem("menu ITEM", tabName = "demo2")
  )),
  
  dashboardBody(
    tabItems(
      tabItem(tabName = "demo",
              fluidRow(h3("dashboardBody"))),
      tabItem(tabName = "demo2",
              fluidRow(h3("dashboard BODY")))))
)

server <- function(input, output) { }

shinyApp(ui, server)

