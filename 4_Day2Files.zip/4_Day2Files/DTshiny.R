library(shiny)
library(mvtnorm)
library(dplyr)
library(DT)

ui <- fluidPage(
  
  titlePanel("DT Demonstration"),
  
  sidebarLayout(
    
    sidebarPanel(
      sliderInput("mean1", label = h4("Group 1 Mean"), min = 200, 
                  max = 500, value = 350, step = 10),
      sliderInput("sd1", label = h4("Group 1 SD"), min = 5, 
                  max = 40, value = 10, step = 1),
      sliderInput("mean2", label = h4("Group 2 Mean"), min = 20, 
                  max = 100, value = 50, step = 5),
      sliderInput("sd2", label = h4("Group 1 SD"), min = 1, 
                  max = 10, value =2, step = 0.50),
      numericInput("sampN", label = h4("Sample Size"), value = 500,
                   min = 100, max = 1000, step = 50),
      numericInput("sampR", label = h4("Sample Correlation"), value = 0,
                   min = -.99, max = .99, step = 0.01)
      
    ),
    
    mainPanel(
      actionButton(inputId = "makeDTtable", label = "Render DT Table Please"),
      dataTableOutput(outputId = "exampleTable"))
  )
)


server <- function(input, output){
  
  rdf <- eventReactive(input$makeDTtable,{
    as.data.frame(round(rmvnorm(input$sampN,
                                mean = c(input$mean1, input$mean2),
                                sigma = diag(sqrt(c(input$sd1, input$sd2))) %*% 
                                  matrix(c(1, input$sampR, input$sampR, 1), nrow = 2) %*%
                                  t(diag(sqrt(c(input$sd1, input$sd2))))))) %>% 
      mutate(ID = 1:input$sampN) %>%
      relocate(ID) %>%
      rename("Variable1" = V1, "Varible2" = V2)
  })
                  
  output$exampleTable <- renderDataTable({rdf()})
  
}


# Run the application 
shinyApp(ui = ui, server = server)
  