
library(shiny)
library(datasets)
library(shinyWidgets)
library(shinydashboard)


ui <- dashboardPage(
  dashboardHeader(title = "State Picker"),
  dashboardSidebar(
    sidebarMenu(
      selectInput("select1", label = h3("Select Flag 1"), 
                  choices = list(state.abb = state.abb), 
                  selected = 1),
      selectInput("select2", label = h3("Select Flag 2"), 
                  choices = list(state.abb = state.abb), 
                  selected = 1)
    )
  ),
  
  dashboardBody(
      box(title = "Flag 1", width = 7, status = "primary", 
          solidHeader = TRUE, collapsible = TRUE,
            imageOutput("state_flag1")
          ),
      box(title = "Flag 2", width = 7, status = "primary", 
          solidHeader = TRUE, collapsible = TRUE,
            imageOutput("state_flag2")
          )
      )
  
    )




server <- function(input, output) {
  
  output$state_flag1 <- renderImage({
    
    return(list(
      src = paste0("www/", tolower(input$select1), ".png"),
      width = 550,
      contentType = "www/png",
      alt = "Face"
    ))
  }, deleteFile = FALSE)
  
  output$state_flag2 <- renderImage({
    
    return(list(
      src = paste0("www/", tolower(input$select2), ".png"),
      width = 550,
      contentType = "www/png",
      alt = "Face"
    ))
  }, deleteFile = FALSE)
}

# Run the application 
shinyApp(ui = ui, server = server)