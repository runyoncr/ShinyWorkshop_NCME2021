
library(shiny)
library(datasets)
library(shinyWidgets)
library(shinydashboard)


  
ui <- dashboardPage(
  dashboardHeader(title = "State Picker"),
  dashboardSidebar(
    sidebarMenu(
      menuItem("ChooseState", tabName = "Choose", icon = icon("hand-pointer")),
      menuItem("StateFlag", tabName = "Flag", icon = icon("flag"))
    )
  ),
  dashboardBody(
    tabItems(
      # First tab content
      tabItem(tabName = "Choose",
              fluidRow(
                column(4,
                       ### Input
                       selectInput("select", label = h3("Select a State"), 
                                   choices = list(state.abb = state.abb), 
                                   selected = 1))
      )),
      
      # Second tab content
      tabItem(tabName = "Flag",
              fluidRow(
                column(4,
                imageOutput("state_flag")
              )))
      )
    )
  )

server <- function(input, output) {
  
  output$state_flag <- renderImage({
    
    return(list(
      src = paste0("www/", tolower(input$select), ".png"),
      contentType = "www/png",
      alt = "Face"
    ))
  }, deleteFile = FALSE)
}

# Run the application 
shinyApp(ui = ui, server = server)