
library(DT)
datatable(iris)
