library(shiny)
library(tidyverse)
# library(readxl)
library(ggpmisc)
library(shinydashboard)
library(DT)
library(plotly)

# Load your data (outside the app but can be used in the app) ----
# loadedData <- read_excel("ageandheight.xls", sheet = "Hoja2")
loadedData <- read_csv("sampleDataset.csv")
dataColumnNames <- colnames(loadedData)


ui <- dashboardPage(
  dashboardHeader(title = "Sample dashboard"),
  dashboardSidebar(
    selectInput(inputId = "columnName1", label = "Select column 1", 
                choices = dataColumnNames, selected = dataColumnNames[1], selectize = TRUE),
    selectInput(inputId = "columnName2", label = "Select column 2",
                choices = dataColumnNames, selected = dataColumnNames[2], selectize = TRUE),
    
    ## Adding in a place for a possible RenderUI ----
    radioButtons(inputId = "methodToIdOutliers", label = "How would you like to select the outlier points?",
      choices = c("X-Axis", "Y-Axis", "Index")),
    uiOutput(outputId = "outlierSelection"),
    actionButton(inputId = "recordNewOutlier", label = "Record"),
    actionButton(inputId = "resetOutliers", label = "Reset Outliers"),
    
    ## textOuput for the submitted outlier list ----
    tags$h3("Outlier Indices:"),
    textOutput(outputId = "outliersIdentified")
  ),
  dashboardBody(
    fluidRow(
      box(title = "Regression Plot", width = 6, status = "primary", solidHeader = TRUE, collapsible = TRUE,
        plotOutput(outputId = "regPlot"),
        downloadButton("downloadRegPlot", "Download Plot")
      ),
      box(title = "Residuals", width = 6, status = "primary", solidHeader = TRUE, collapsible = TRUE,
        plotOutput(outputId = "residualPlot")
      )
    ),
    fluidRow(
      box(title = "Residuals Data Table", width = 6, status = "primary", solidHeader = TRUE, collapsible = TRUE,
        dataTableOutput(outputId = "residualTable")
      ),
      box(title = "Outlier Detection", width = 6, status = "primary", solidHeader = TRUE, collapsible = TRUE,
        # plotOutput(outputId = "cooksDistancePlot")
        plotlyOutput(outputId = "cooksDistancePlot")
      )
    )
  )
)


server <- function(input, output) {
  
  ## Initialize Reactive Values
  outliers <- reactiveValues(indices = NULL)
  
  ## Reactive Expressions ----
  reactiveData <- reactive({
    df <- loadedData %>% 
      mutate(RowNumber = row_number()) %>% 
      rename(x = input$columnName1, y = input$columnName2)
    if(is.null(outliers$indices)){
      return(df)
    }else{
      return(dplyr::slice(df, -1*outliers$indices))
    }
  })

  regressionModel <- reactive({
    my.formula <- y ~ x
    lmHeight <- lm(my.formula, data = reactiveData())
    # lmHeight <- lm(my.formula, data = loadedData)
  })
  
  reactiveRegPlot <- reactive({
    my.formula <- y ~ x
    ggplot(data = reactiveData(), aes(x=x, y=y)) + 
      geom_point() + 
      geom_smooth(method=lm) +
      stat_poly_eq(formula = my.formula,
                   eq.with.lhs = "italic(hat(y))~`=`~",
                   aes(label = paste(..eq.label.., ..rr.label.., sep = "~~~")),
                   parse = TRUE) + 
      theme_bw()
  })
  
  output$regPlot <- renderPlot({
    reactiveRegPlot()
  })
  
  output$downloadRegPlot <- downloadHandler(
    filename = "RegressionPlot.png",
    content = function(file) {
      ggsave(filename = file, plot = reactiveRegPlot())
    }
  )
  
  output$residualPlot <- renderPlot({
    # lmHeight = lm(height~age, data = loadedData)
    newModel <- regressionModel()
    plot(newModel$residuals, pch = 16, col = "blue")
  })
  
  output$residualTable <- renderDataTable({
    newModel <- regressionModel()
    
    reactiveData() %>% 
      mutate(Index = row_number(),
             Residuals = newModel$residuals) %>% 
      select(x, y, Index, Residuals) %>% # Cutting down on the number of columns to just the relevant ones
      # select(-RowNumber) %>% 
      arrange(desc(Residuals)) %>% 
      datatable(rownames=FALSE)
  })
  
  output$cooksDistancePlot <- renderPlotly({
  # output$cooksDistancePlot <- renderPlot({
    newModel <- regressionModel()
    
    distances <- cooks.distance(newModel)
    distanceDF <- data.frame(Index = as.integer(names(distances)), "Cooks_Distance" = distances)
    
    p <- ggplot(data = distanceDF, aes(x=Index, y=`Cooks_Distance`)) + 
      geom_point()
    # p
    ggplotly(p)
  })
  
  ## RenderUI code ----
  output$outlierSelection <- renderUI({
    df <- reactiveData()
    
    if(input$methodToIdOutliers == "X-Axis"){
      dataChoices <- sort(df$x)
      selectInput(inputId = "outlierInput", label = "Select the X-Axis value of the new outlier and click Record",
                  choices = dataChoices, selectize = TRUE)
    }else if(input$methodToIdOutliers == "Y-Axis"){
      dataChoices <- sort(df$y)
      selectInput(inputId = "outlierInput", label = "Select the Y-Axis value of the new outlier and click Record",
                  choices = dataChoices, selectize = TRUE)
    }else{
      dataChoices <- 1:nrow(df)
      selectInput(inputId = "outlierInput", label = "Select the row number/index of the new outlier and click Record",
                  choices = dataChoices, selectize = TRUE)
    }
  })
  
  ## Button click actions (observeEvents) ----
  # actionButton(inputId = "recordNewOutlier", label = "Record"),
  # actionButton(inputId = "resetOutliers", label = "Reset Outliers"),
  observeEvent(input$recordNewOutlier, {
    df <- reactiveData()
    
    outlierValue <- as.numeric(input$outlierInput)
    
    if(input$methodToIdOutliers == "X-Axis"){
      outlierIndex <- df[which(df$x == outlierValue)[1], "RowNumber"]
    }else if(input$methodToIdOutliers == "Y-Axis"){
      outlierIndex <- df[which(df$y == outlierValue)[1], "RowNumber"]
    }else{
      outlierIndex <- df[outlierValue, "RowNumber"]
      # outlierIndex <- as.integer(outlierValue)
    }
    
    #Using the reactive variable to keep a vector of your outliers
    #Add new outliers to the vector since the user pressed the button
    outliers$indices <- sort(unique(c(outliers$indices, as.integer(outlierIndex))))
  })
  
  output$outliersIdentified <- renderText({
    if(is.null(outliers$indices)){
      return("None")
    }else{
      return(paste0(outliers$indices, collapse = ", "))
    }
  })
  
  observeEvent(input$resetOutliers, {
    outliers$indices <- NULL
  })

}

shinyApp(ui, server)
