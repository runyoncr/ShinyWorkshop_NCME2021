
library(shiny)
library(datasets)
library(shinyWidgets)
library(shinydashboard)
library(shinyjs)


  
ui <- dashboardPage(
  
  skin = "yellow",
  dashboardHeader(title = "Data Explorer"),
  
  dashboardSidebar(
    sidebarMenu(
      menuItem("Data Gen Model", tabName = "datagen"),
      menuItem("Table", tabName = "dt_output"),
      menuItem("Plot", tabName = "plotly_output"))),

  dashboardBody(
    tabItems(
      tabItem(tabName = "datagen",
              fluidRow(
                column(6, sliderInput("mean1", label = h4("Group 1 Mean"), min = 200, 
                                      max = 500, value = 350, step = 10)),
                column(6, sliderInput("mean2", label = h4("Group 2 Mean"), min = 20,
                                      max = 100, value = 50, step = 5))),
              fluidRow(
                column(6, sliderInput("sd1", label = h4("Group 1 SD"), min = 5,
                                      max = 40, value = 10, step = 1)),
                column(6, sliderInput("sd2", label = h4("Group 2 SD"), min = 1,
                                      max = 10, value =2, step = 0.50))),
              fluidRow(
                column(4, numericInput("sampN", label = h4("Sample Size"), value = 500,
                                       min = 100, max = 1000, step = 50)),
                column(4, numericInput("sampR", label = h4("Sample Correlation"), value = 0,
                                       min = -.99, max = .99, step = 0.01)),
                column(4, actionButton(inputId = "genData", 
                          label = "Generate Data")))),

      tabItem(tabName = "dt_output",  dataTableOutput(outputId = "exampleTable")),
      
      tabItem(tabName = "plotly_output",  plotlyOutput(outputId = "examplePlotly")))))

server <- function(input, output) {
  
  rdf <- eventReactive(input$genData,{
    as.data.frame(round(rmvnorm(input$sampN,
                                mean = c(input$mean1, input$mean2),
                                sigma = diag(sqrt(c(input$sd1, input$sd2))) %*% 
                                  matrix(c(1, input$sampR, input$sampR, 1), nrow = 2) %*%
                                  t(diag(sqrt(c(input$sd1, input$sd2))))))) %>% 
      mutate(ID = 1:input$sampN) %>%
      relocate(ID) %>%
      rename("Variable1" = V1, "Variable2" = V2)
  })

  output$exampleTable <- renderDataTable({rdf()})
  
  output$examplePlotly <- renderPlotly({
    p <- ggplot(data = rdf(), aes(x = Variable1, y = Variable2)) + 
      geom_count() + geom_smooth()
    ggplotly(p)
  })

}

# Run the application 
shinyApp(ui = ui, server = server)